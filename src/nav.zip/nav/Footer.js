import React from 'react'
import './footer.style.css'
const Footer = () => {
  return (
   <>
   <div className='footer'>
   <h3 >Clinic Home page</h3>
   </div>
   </>


  )
}

export default Footer